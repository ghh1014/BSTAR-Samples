﻿using ControlsDemo.Models;
using WallE.Core;

namespace ControlsDemo.Views
{
    /// <summary>
    /// DemoCreateView.xaml 的交互逻辑
    /// </summary>
    public partial class DemoCreateView
    {
        public DemoCreateView()
        {
            InitializeComponent();
        }
    }
}