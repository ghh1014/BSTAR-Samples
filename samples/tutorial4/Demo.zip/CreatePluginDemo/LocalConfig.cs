﻿namespace CreatePluginDemo
{
    public class LocalConfig
    {
         
    }
}