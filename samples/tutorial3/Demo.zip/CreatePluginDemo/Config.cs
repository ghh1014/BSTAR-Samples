﻿namespace CreatePluginDemo
{
    public class Config
    {
         
    }
}