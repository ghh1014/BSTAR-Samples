﻿using WallE.Core;

namespace CreatePluginDemo.ViewModels
{
    public class FirstViewModel:ViewModelBase
    {
         
    }
}