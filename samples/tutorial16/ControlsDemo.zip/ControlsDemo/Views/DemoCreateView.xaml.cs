﻿using ControlsDemo.Models;
using WallE.Core;

namespace ControlsDemo.Views
{
    /// <summary>
    /// DemoCreateView.xaml 的交互逻辑
    /// </summary>
    public partial class DemoCreateView : IHandle<User>
    {
        public DemoCreateView()
        {
            InitializeComponent();
        }

        protected override void OnLoaded(bool isFirstLoad)
        {
            base.OnLoaded(isFirstLoad);
            //消息发送
            Messager.Send(this, new Message<string>("ViewToViewModel", "我是通信消息2"));
            var user = new User { Number = "4", Name = "小黑", Remark = "-" };
            Messager.Send(this, new Message<User>("ViewToViewModel", user));
        }

        /// <summary>
        /// string消息接收
        /// </summary>
        /// <param name="message">string</param>
        public override void Handle(Message<string> message)
        {
            base.Handle(message);
            if (message.Name == "ViewModelToView")
            {
                //进行一些操作
                Btn.Content = $"{message.Value}";
            }
        }

        /// <summary>
        /// 实体数据消息接收
        /// </summary>
        /// <param name="message">User实体</param>
        public void Handle(Message<User> message)
        {
            throw new System.NotImplementedException();
        }
    }
}