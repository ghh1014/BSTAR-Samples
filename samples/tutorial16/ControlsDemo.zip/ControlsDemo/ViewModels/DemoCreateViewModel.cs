﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Threading.Tasks;
using ControlsDemo.Models;
using WallE.Assist;
using WallE.Core;

namespace ControlsDemo.ViewModels
{
    public class DemoCreateViewModel : ViewModelBase, IHandle<User>
    {
        public DemoCreateViewModel()
        {
            YearList = new List<Tuple<string, string>>
            {
                new Tuple<string, string>("2017", "2017年"),
                new Tuple<string, string>("2018", "2018年"),
                new Tuple<string, string>("2019", "2019年")
            };
            IsBusy = true;
            UserSource = new ObservableCollection<User>
            {
                new User{Number = "1",Name="小茗",Remark="-"},
                new User{Number = "2",Name="冷冷",Remark="-"},
                new User{Number = "3",Name="暖暖",Remark="-"}
            };
            _bakUserSource = new List<User>();
            _bakUserSource.AddRange(UserSource);
            IsBusy = false;
            ClickMe = new RelayCommand(OnClickMe, CanClickMe);

            Search = OnSearchAsync;
        }

        private List<Tuple<string, string>> _yearList;

        /// <summary>
        /// 年份列表
        /// </summary>
        public List<Tuple<string, string>> YearList
        {
            get { return _yearList; }
            set { Set("YearList", ref _yearList, value); }
        }

        private ObservableCollection<User> _userSource;

        /// <summary>
        /// 获取或设置UserSource属性
        /// </summary>
        public ObservableCollection<User> UserSource
        {
            get { return _userSource; }
            set { Set("UserSource", ref _userSource, value); }
        }

        private List<User> _bakUserSource;

        private User _userItem;

        /// <summary>
        /// 获取或设置UserItem属性
        /// </summary>
        public User UserItem
        {
            get { return _userItem; }
            set { Set("UserItem", ref _userItem, value); }
        }

        #region ClickMe

        public RelayCommand ClickMe { get; private set; }

        private bool CanClickMe()
        {
            return true;
        }

        private void OnClickMe()
        {
            Messager.Send(this, new Message<string>("ViewModelToView", "我是一条通信消息"));
        }

        #endregion ClickMe

        private bool _isBusy;

        /// <summary>
        /// 获取或设置IsBusy属性
        /// </summary>
        public bool IsBusy
        {
            get { return _isBusy; }
            set { Set("IsBusy", ref _isBusy, value); }
        }

        private string _title;

        [Required(ErrorMessage = "Title不能为空！")]
        public string Title
        {
            get { return _title; }
            set { Set("Title", ref _title, value); }
        }

        #region SearchBox

        public Func<string, Task> Search { get; private set; }

        private async Task OnSearchAsync(string searchStr)
        {
            if (string.IsNullOrEmpty(searchStr))
            {
                UserSource = new ObservableCollection<User>();
                UserSource.AddRange(_bakUserSource);
            }
            var searchItems = await Task.Run(() =>
            {
                var items = new ObservableCollection<User>();
                if (searchStr == null) return items;
                searchStr = searchStr.ToLower().Trim();
                foreach (var item in _bakUserSource)
                {
                    if (ContainsString(item.Number + "", searchStr)
                        || ContainsString(item.Name, searchStr)
                        || ContainsString(item.Remark, searchStr)
                        )
                    {
                        items.Add(item);
                    }
                }
                return items;
            });
            UserSource = new ObservableCollection<User>(searchItems);
        }

        private static bool ContainsString(string str, string searchStr)
        {
            return str != null && str.Contains(searchStr, CompareOptions.IgnoreCase);
        }

        #endregion SearchBox

        #region 消息通信

        /// <summary>
        /// string消息接收
        /// </summary>
        /// <param name="message"></param>
        public void Handle(Message<string> message)
        {
            if (message.Name == "ViewToViewModel")
            {
                //进行一些操作
                Title = $"{message.Value}";
            }
        }

        /// <summary>
        /// 实体数据消息接收
        /// </summary>
        /// <param name="message"></param>
        public void Handle(Message<User> message)
        {
            if (message.Name == "ViewToViewModel")
            {
                //进行一些操作
                UserSource.Add(message.Value);
            }
        }

        #endregion 消息通信
    }
}