﻿using System.Collections.Generic;
using ControlsDemo.ViewModels;
using WallE.Core;

namespace ControlsDemo
{
    public class MainPlugin : IPlugin
    {
        public static Dictionary<string, DockingPaneViewModel> DemoPlanVmsDic;

        public void Install(IPluginInfo pluginInfo)
        {
            DemoPlanVmsDic = new Dictionary<string, DockingPaneViewModel>();
            var dm = new DockingPaneViewModel(new DemoCreateViewModel())
            {
                Header = "Demo",
                IsDocument = true
            };
            DemoPlanVmsDic["demo"] = dm;
            M.DockingManager.InsertPane(dm);
        }

        public void Uninstall()
        {
        }
    }
}